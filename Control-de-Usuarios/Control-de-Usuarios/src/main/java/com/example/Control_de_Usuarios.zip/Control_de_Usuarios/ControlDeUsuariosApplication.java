package com.example.Control_de_Usuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlDeUsuariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControlDeUsuariosApplication.class, args);
	}

}
