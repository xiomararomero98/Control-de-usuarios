package com.example.Control_de_Usuarios.Model;

public class Privilegios {

}
