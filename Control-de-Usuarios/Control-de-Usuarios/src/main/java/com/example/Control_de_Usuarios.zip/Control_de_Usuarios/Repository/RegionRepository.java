package com.example.Control_de_Usuarios.Repository;

public interface RegionRepository {

}
